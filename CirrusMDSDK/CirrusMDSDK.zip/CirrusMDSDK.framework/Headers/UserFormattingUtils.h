//
//  CirrusMD
//
//  Created by David Nix on 8/5/15.
//  Copyright (c) 2015 CirrusMD. All rights reserved.
//

#import <Foundation/Foundation.h>

NSString* _Nullable FormattedDOBString(NSDate* _Nullable dob);

NSDate* _Nullable FormattedDOBDate(NSString* _Nullable dob);

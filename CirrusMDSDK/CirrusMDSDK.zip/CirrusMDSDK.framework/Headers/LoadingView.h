//
//  LoadingView.h
//  CirrusMD
//
//  Created by David Nix on 9/15/15.
//  Copyright (c) 2015 CirrusMD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoadingView : UIView

@end
